# MyRoom Game — prototype

Ini adalah prototype Android untuk konsep game sosial "MyRoom":
- Pilih karakter pria/wanita
- Masuk daftar room
- Room 2D sederhana
- Gerakkan karakter
- Chat room lokal (prototype)
- Tombol undang teman lewat WhatsApp menggunakan link room
- Profil dan pengaturan

## Cara menjadi APK
Buka folder ini di Android Studio, tunggu Gradle selesai, lalu:
Build > Build APK(s)

Catatan:
Prototype ini belum memiliki server multiplayer sungguhan. Untuk teman bermain dari HP berbeda, tahap berikutnya membutuhkan backend realtime (akun, room ID, sinkronisasi posisi, chat, keamanan, dan database).
