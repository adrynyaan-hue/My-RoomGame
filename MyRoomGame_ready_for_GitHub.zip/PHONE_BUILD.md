
PHONE-ONLY BUILD
1. Create a GitHub repository.
2. Upload the contents of this project to the repository.
3. Open the Actions tab and run "Build MyRoom APK".
4. When the workflow finishes, open the run and download the "MyRoom-debug-apk" artifact.
